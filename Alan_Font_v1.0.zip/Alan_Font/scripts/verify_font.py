"""Independent release checks: coverage, Arabic joining, names and regressions."""
from pathlib import Path
import hashlib
import json
import sys
from fontTools.ttLib import TTFont
import uharfbuzz as hb

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'sources/Lalezar-Regular.ttf'
OUT = ROOT / 'fonts/AlanFont-Regular.ttf'
TARGETS = 'ڕڵۆێە'
base = TTFont(BASE)
font = TTFont(OUT)
order = font.getGlyphOrder()
buf_font = hb.Font(hb.Face(OUT.read_bytes()))
base_hb = hb.Font(hb.Face(BASE.read_bytes()))

def shape(text, face=buf_font, features=None):
    buf = hb.Buffer()
    buf.add_str(text)
    buf.direction = 'rtl'
    buf.script = 'arab'
    buf.language = 'ckb'
    hb.shape(face, buf, features or {})
    return [(i.codepoint, i.cluster, p.x_advance, p.y_advance, p.x_offset, p.y_offset) for i, p in zip(buf.glyph_infos, buf.glyph_positions)]

checks = {}
checks['all_original_cmap_entries_preserved'] = all(font.getBestCmap().get(c) == g for c, g in base.getBestCmap().items())
checks['all_original_glyph_ids_preserved'] = order[:len(base.getGlyphOrder())] == base.getGlyphOrder()
checks['five_sorani_nominal_characters_present'] = all(ord(c) in font.getBestCmap() for c in TARGETS)
lyrics_path = ROOT.parent / 'sorani_apartment_love_song/analysis/sorani_cues.json'
lyrics = json.loads(lyrics_path.read_text()) if lyrics_path.exists() else [
    {'ckb': line} for line in (ROOT / 'tests/sorani_samples.txt').read_text().splitlines()
    if line.strip() and not line.startswith('#')
]
checks['test_text_has_no_missing_glyphs'] = bool(lyrics) and all(all(x[0] != 0 for x in shape(c['ckb'])) for c in lyrics)

joining = {}
for c in TARGETS:
    samples = [c, 'ب'+c, c+'ب', 'ب'+c+'ب']
    target_indices = [0, 1, 0, 1]
    ids = []
    for sample, index in zip(samples, target_indices):
        result = shape(sample, features={'liga': False, 'rlig': False, 'calt': False})
        selected = [x[0] for x in result if x[1] == index]
        ids.append(selected[0] if len(selected) == 1 else None)
    ok = len(set(ids)) == 4 if c in 'ڵێ' else ids[0] == ids[2] and ids[1] == ids[3] and ids[0] != ids[1]
    ok = ok and None not in ids and 0 not in ids
    joining[c] = {'samples': samples, 'glyphs': [order[g] if g is not None else None for g in ids], 'passed': ok}
checks['correct_dual_and_right_joining'] = all(v['passed'] for v in joining.values())

regressions = ['سلام', 'فارسی', 'کتاب', 'ملک', 'علی', 'نوری', 'کوردی', 'ببب', 'ییی', 'لا', 'الله', 'Alan Font 2026']
checks['original_shaping_unchanged'] = all(shape(s) == shape(s, base_hb) for s in regressions)
new_words = ['ڕێگایەکی', 'ساڵەکان', 'پاڵتۆ', 'هێنا', 'شێوە', 'ماڵەوە', 'ڵا', 'ڵە', 'ڵێ', 'ڕۆژ', 'کۆڵێڕە']
checks['context_words_have_no_notdef'] = all(all(x[0] for x in shape(s)) for s in new_words)

name = lambda n: font['name'].getDebugName(n)
checks['release_naming'] = name(1) == 'Alan Font' and name(2) == 'Regular' and name(4) == 'Alan Font Regular' and name(6) == 'AlanFont-Regular'
checks['copyright_retained'] = 'Copyright 2015 The Lalezar Project Authors' in (name(0) or '')
checks['embedding_permissions_unchanged'] = font['OS/2'].fsType == base['OS/2'].fsType
woff = ROOT / 'fonts/AlanFont-Regular.woff2'
checks['woff2_matches_ttf_coverage'] = woff.exists() and TTFont(woff).getBestCmap() == font.getBestCmap()

report = {'ok': all(checks.values()), 'checks': checks, 'joining': joining, 'new_context_words': new_words, 'regression_samples': regressions, 'song_cues_checked': len(lyrics), 'names': {str(i): name(i) for i in (0,1,2,3,4,5,6,9,13,16,17)}, 'sha256': hashlib.sha256(OUT.read_bytes()).hexdigest()}
(ROOT / 'review/independent_font_checks.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
print(json.dumps({'ok': report['ok'], 'checks': checks, 'joining': joining}, ensure_ascii=False, indent=2))
sys.exit(0 if report['ok'] else 1)
