#!/usr/bin/env python3
"""Build Alan Font, an OFL Sorani adaptation of Lalezar, without replacing OT tables.

Requires fontTools, uharfbuzz, and brotli. The unchanged upstream font and OFL
license belong in ../sources. Run with the project's isolated PYTHONPATH.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

import uharfbuzz as hb
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont
from fontTools.ttLib.tables import otTables

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "sources" / "Lalezar-Regular.ttf"
OUTPUT = ROOT / "fonts"

# Unicode joining types: REH/WAW/AE are right-joining; LAM/FARSI YEH dual.
BASES = {
    0x0695: {"isol": "uni0631", "fina": "uniFEAE"},
    0x06B5: {"isol": "uni0644", "fina": "uniFEDE", "init": "uniFEDF", "medi": "uniFEE0"},
    0x06C6: {"isol": "uni0648", "fina": "uniFEEE"},
    0x06CE: {"isol": "uni06CC", "fina": "uniFBFD", "init": "uniFBFE", "medi": "uniFBFF"},
    # These are the actual dotless bodies used by Lalezar's TEH MARBUTA.
    0x06D5: {"isol": "uni0647.comb", "fina": "uniFEEA.comb"},
}


def read_test_samples(external_lyrics_path=None):
    """Use optional local integration lyrics, or the public generic test corpus.

    The public font repository intentionally ships no original song or lyrics.
    Its generic Sorani samples are sufficient for a standalone font rebuild.
    """
    if external_lyrics_path is None:
        external_lyrics_path = ROOT.parent / "sorani_apartment_love_song" / "analysis" / "embedded_lyrics.txt"
    external_lyrics_path = Path(external_lyrics_path)
    source = external_lyrics_path if external_lyrics_path.is_file() else ROOT / "tests" / "sorani_samples.txt"
    return source.read_text(encoding="utf-8"), source


def shape(data, text, features=None):
    face = hb.Face(data)
    font = hb.Font(face)
    font.scale = (face.upem, face.upem)
    buffer = hb.Buffer()
    buffer.add_str(text)
    buffer.guess_segment_properties()
    if any("\u0600" <= x <= "\u06ff" for x in text):
        buffer.direction, buffer.script, buffer.language = "rtl", "arab", "ckb"
    hb.shape(font, buffer, features or {})
    return [(i.codepoint, i.cluster, p.x_advance, p.y_advance, p.x_offset, p.y_offset)
            for i, p in zip(buffer.glyph_infos, buffer.glyph_positions)]


def build():
    original_bytes = SOURCE.read_bytes()
    font = TTFont(SOURCE, recalcTimestamp=False)
    original_order = font.getGlyphOrder()
    glyf, metrics = font["glyf"], font["hmtx"].metrics
    added_from = {}
    glyph_forms = {}

    # One down-pointing small V; thick, soft proportions match Lalezar's weight.
    pen = TTGlyphPen(None)
    pen.moveTo((-74, 88))
    pen.lineTo((-39, 111))
    pen.lineTo((0, 56))
    pen.lineTo((39, 111))
    pen.lineTo((74, 88))
    pen.lineTo((0, -15))
    pen.closePath()
    mark_name = "alan.smallV"
    glyf[mark_name] = pen.glyph()
    metrics[mark_name] = (0, -74)
    font.setGlyphOrder(original_order + [mark_name])

    def bounds(name):
        glyph = glyf[name]
        glyph.recalcBounds(glyf)
        return glyph.xMin, glyph.yMin, glyph.xMax, glyph.yMax

    def mark_origin(cp, form, base):
        x0, y0, x1, y1 = bounds(base)
        if cp == 0x0695:
            # Below the descending REH bowl, preserving 40 units of clearance.
            return (76, y0 - 40 - 111)
        if cp == 0x06B5:
            # Above the tall lam upright; its x position differs in joining forms.
            return (468 if form in ("isol", "fina") else 166, y1 + 40 + 15)
        if cp == 0x06C6:
            return (198, y1 + 42 + 15)
        if cp == 0x06CE:
            # V above the yeh body; keep Farsi yeh's dotless isol/final and
            # original two-dot init/medi construction intact.
            if form == "isol":
                return (325, 325)
            if form == "fina":
                return (330, 330)
            return ((142 if form == "init" else 183), y1 + 42 + 15)
        raise AssertionError(cp)

    def composite(name, base, marks=(), metric_base=None):
        if name in glyf:
            return name
        pen = TTGlyphPen(glyf)
        pen.addComponent(base, (1, 0, 0, 1, 0, 0))
        for x, y in marks:
            pen.addComponent(mark_name, (1, 0, 0, 1, round(x), round(y)))
        glyf[name] = pen.glyph()
        metrics[name] = metrics[metric_base or base]
        added_from[name] = metric_base or base
        font.setGlyphOrder(list(dict.fromkeys(font.getGlyphOrder() + [name])))
        return name

    for cp, forms in BASES.items():
        glyph_forms[cp] = {}
        for form, base in forms.items():
            name = f"alan{cp:04X}" + ("" if form == "isol" else "." + form)
            marks = [] if cp == 0x06D5 else [mark_origin(cp, form, base)]
            # AE inherits TEH MARBUTA metrics, with only the dots removed.
            metric_base = ("uni0629" if form == "isol" else "uniFE94") if cp == 0x06D5 else base
            composite(name, base, marks, metric_base)
            glyph_forms[cp][form] = name

    # Add Unicode mappings to every compatible Unicode cmap. Existing entries
    # and all original glyph indices are retained.
    for table in font["cmap"].tables:
        if table.isUnicode() and table.format in (4, 12):
            for cp, forms in glyph_forms.items():
                table.cmap[cp] = forms["isol"]

    # Append joining lookups to existing feature records. No feaLib rebuild:
    # source scripts, language systems, lookups, contextual rules all survive.
    gsub = font["GSUB"].table
    original_lookup_count = len(gsub.LookupList.Lookup)
    for form in ("fina", "init", "medi"):
        substitution = otTables.SingleSubst()
        substitution.mapping = {forms["isol"]: forms[form]
                                for forms in glyph_forms.values() if form in forms}
        lookup = otTables.Lookup()
        lookup.LookupType, lookup.LookupFlag = 1, 0
        lookup.SubTable, lookup.SubTableCount = [substitution], 1
        index = len(gsub.LookupList.Lookup)
        gsub.LookupList.Lookup.append(lookup)
        for record in gsub.FeatureList.FeatureRecord:
            if record.FeatureTag == form:
                record.Feature.LookupListIndex.append(index)
                record.Feature.LookupCount = len(record.Feature.LookupListIndex)
    gsub.LookupList.LookupCount = len(gsub.LookupList.Lookup)

    # Preserve LAM's existing ligature behavior for LAM WITH SMALL V. A marked
    # composite of the exact source ligature retains all join endpoints.
    lam_forms = glyph_forms[0x06B5]
    lam_base_to_form = {base: form for form, base in BASES[0x06B5].items()}
    liga_count = 0
    for lookup in gsub.LookupList.Lookup[:original_lookup_count]:
        for sub in lookup.SubTable:
            if not hasattr(sub, "ligatures"):
                continue
            for base, form in lam_base_to_form.items():
                if base not in sub.ligatures:
                    continue
                new_ligatures = []
                for index, entry in enumerate(sub.ligatures[base]):
                    clone = copy.deepcopy(entry)
                    new_name = "alan.lamV." + entry.LigGlyph
                    x0, y0, x1, y1 = bounds(entry.LigGlyph)
                    # Source LAM ALEF upright sits near right side of ligature.
                    # Keep one V centered over the lam stem without reshaping it.
                    coords, _, _ = glyf[entry.LigGlyph].getCoordinates(glyf)
                    xs = [x for x, y in coords if y >= y1 - 80]
                    center = (min(xs) + max(xs)) / 2 if xs else (x0 + x1) / 2
                    composite(new_name, entry.LigGlyph, [(center, y1 + 40 + 15)])
                    clone.LigGlyph = new_name
                    new_ligatures.append(clone)
                    liga_count += 1
                sub.ligatures[lam_forms[form]] = new_ligatures

    # Inherit glyph classes and carets. New base letters remain bases, not marks.
    gdef = font["GDEF"].table
    for new, base in added_from.items():
        if gdef.GlyphClassDef:
            gdef.GlyphClassDef.classDefs[new] = gdef.GlyphClassDef.classDefs.get(base, 1)
        if gdef.MarkAttachClassDef and base in gdef.MarkAttachClassDef.classDefs:
            gdef.MarkAttachClassDef.classDefs[new] = gdef.MarkAttachClassDef.classDefs[base]
    if gdef.GlyphClassDef:
        gdef.GlyphClassDef.classDefs[mark_name] = 3

    def extend_coverage(coverage, records, record_attribute):
        old = dict(zip(coverage.glyphs, getattr(records, record_attribute)))
        for new, base in added_from.items():
            if base in old:
                old[new] = copy.deepcopy(old[base])
        names = sorted(old, key=font.getGlyphID)
        coverage.glyphs = names
        setattr(records, record_attribute, [old[name] for name in names])
        count_name = {"BaseRecord": "BaseCount", "LigatureAttach": "LigatureCount", "EntryExitRecord": "EntryExitCount"}.get(record_attribute)
        if count_name:
            setattr(records, count_name, len(names))

    # Carry all applicable base/ligature mark anchors to the new composites.
    for lookup in font["GPOS"].table.LookupList.Lookup:
        for sub in lookup.SubTable:
            if hasattr(sub, "BaseCoverage"):
                extend_coverage(sub.BaseCoverage, sub.BaseArray, "BaseRecord")
            if hasattr(sub, "LigatureCoverage"):
                extend_coverage(sub.LigatureCoverage, sub.LigatureArray, "LigatureAttach")
            # Pair-position classes retain the source base's membership.
            for attribute in ("ClassDef1", "ClassDef2"):
                classdef = getattr(sub, attribute, None)
                if classdef:
                    for new, base in added_from.items():
                        if base in classdef.classDefs:
                            classdef.classDefs[new] = classdef.classDefs[base]
    if gdef.LigCaretList:
        extend_coverage(gdef.LigCaretList.Coverage, gdef.LigCaretList, "LigGlyph")
        gdef.LigCaretList.LigGlyphCount = len(gdef.LigCaretList.LigGlyph)

    # Rename all platform records while retaining upstream copyright/license.
    names = font["name"]
    strings = {
        1: "Alan Font", 2: "Regular", 3: "1.000;AlanFont;AlanFont-Regular",
        4: "Alan Font Regular", 5: "Version 1.000", 6: "AlanFont-Regular",
        9: "Base design: Borna Izadpanah. Sorani adaptation: Alan Font project.",
        10: "Alan Font is an OFL Sorani adaptation of Lalezar. Added Sorani letterforms and joining support; the original Lalezar design remains credited to its authors.",
        16: "Alan Font", 17: "Regular", 18: "Alan Font Regular", 21: "Alan Font", 22: "Regular",
    }
    names.names = [record for record in names.names if record.nameID not in strings]
    for name_id, value in strings.items():
        names.setName(value, name_id, 3, 1, 0x409)
        names.setName(value, name_id, 0, 4, 0)
    font["head"].fontRevision = 1.0

    # Maintain the generous original line metrics, extending only if necessary.
    for name in added_from:
        bounds(name)
    lowest = min(glyf[n].yMin for n in added_from)
    highest = max(glyf[n].yMax for n in added_from)
    font["hhea"].ascent = max(font["hhea"].ascent, highest + 40)
    font["hhea"].descent = min(font["hhea"].descent, lowest - 40)
    font["OS/2"].sTypoAscender = max(font["OS/2"].sTypoAscender, highest + 40)
    font["OS/2"].sTypoDescender = min(font["OS/2"].sTypoDescender, lowest - 40)
    font["OS/2"].usWinAscent = max(font["OS/2"].usWinAscent, highest + 40)
    font["OS/2"].usWinDescent = max(font["OS/2"].usWinDescent, -lowest + 40)

    OUTPUT.mkdir(parents=True, exist_ok=True)
    target = OUTPUT / "AlanFont-Regular.ttf"
    font.save(target)
    font.flavor = "woff2"
    font.save(OUTPUT / "AlanFont-Regular.woff2")
    data = target.read_bytes()
    reopened = TTFont(target)
    cmap = reopened.getBestCmap()
    lyrics, test_source = read_test_samples()
    missing = sorted({c for c in lyrics + "ڕڵۆێەڤکی" if not c.isspace() and ord(c) not in cmap})
    assert not missing, missing
    assert reopened.getGlyphOrder()[:len(original_order)] == original_order

    controls = ["سلام", "العربية", "لاله زار", "فارسی", "کیک", "Hello Alan 123", "لا لأ لإ لآ"]
    control_results = {text: shape(original_bytes, text) == shape(data, text) for text in controls}
    assert all(control_results.values()), control_results
    cue_texts = [line for line in lyrics.splitlines() if line and not line.startswith("[")]
    for line in cue_texts:
        assert all(item[0] for item in shape(data, line)), line
    probes = ["ڕ", "بڕ", "ڕێ", "ڕۆ", "ڵ", "بڵ", "ڵب", "بڵب", "ڵا", "ڵە", "ڵێ",
              "ۆ", "بۆ", "ێ", "بێ", "ێب", "بێب", "ە", "بە", "ەب", "بەب"]
    probe_results = {}
    for text in probes:
        result = shape(data, text)
        assert all(item[0] for item in result), text
        probe_results[text] = [reopened.getGlyphName(item[0]) for item in result]
    # Right-joining AE must never acquire an initial or medial glyph.
    assert not any("alan06D5.init" in str(v) or "alan06D5.medi" in str(v) for v in probe_results.values())
    original_copyright = [x.toUnicode() for x in TTFont(SOURCE)["name"].names if x.nameID == 0]
    assert [x.toUnicode() for x in reopened["name"].names if x.nameID == 0] == original_copyright
    report = {
        "font": str(target), "sha256": hashlib.sha256(data).hexdigest(),
        "new_glyphs": len(added_from) + 1, "new_unicode_characters": [f"U+{cp:04X}" for cp in BASES],
        "new_lam_ligature_rules": liga_count, "test_text_source": str(test_source),
        "text_lines_notdef_free": len(cue_texts),
        "missing_characters": missing, "unchanged_source_shaping": control_results,
        "new_glyph_y_bounds": [lowest, highest], "hhea_line_metrics": [reopened["hhea"].ascent, reopened["hhea"].descent],
        "shaping_probes": probe_results, "source_copyright_preserved": True,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return report


if __name__ == "__main__":
    build()
