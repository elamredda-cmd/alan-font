Alan Font
Sorani adaptation: Alan Font project

Alan Font is a renamed, focused Sorani adaptation of Lalezar. The original
Lalezar design is by Borna Izadpanah. Its upstream copyright is preserved:
Copyright 2015 The Lalezar Project Authors (https://github.com/BornaIz/Lalezar)

This adaptation adds support for five Sorani letters used in the project:
  ڕ  U+0695  ARABIC LETTER REH WITH SMALL V BELOW
  ڵ  U+06B5  ARABIC LETTER LAM WITH SMALL V
  ۆ  U+06C6  ARABIC LETTER OE
  ێ  U+06CE  ARABIC LETTER YEH WITH SMALL V
  ە  U+06D5  ARABIC LETTER AE

The family name is Alan Font. This release builds on the original Lalezar
font; its underlying design and authorship remain credited to that project.
The adaptation credit does not claim sole authorship of the original font
or endorsement by its original authors. This is a focused extension for
Sorani text, rather than a guarantee of every language or shaping scenario.

License and reuse

The font is distributed under the SIL Open Font License 1.1 in OFL.txt.
You may use it for personal and commercial work, embed it, copy it,
redistribute it, and modify it under that license. Graphics, videos and
documents made with the font do not have to use the OFL.

When redistributing the font or a modified version, retain the original
copyright notice and the complete OFL 1.1 license, and keep the font under
the OFL. The font or its components must not be sold by themselves.
The original authors' names may acknowledge their contributions; their
endorsement must not be implied. See OFL.txt for the complete conditions.

The actual upstream Lalezar license supplied with this release declares
no Reserved Font Names. This adaptation also declares no new Reserved
Font Names. Alan Font is the chosen family name for this modified version.

Installation and web use

For desktop installation, open the supplied .ttf file with your system's
font installer. For web use, use the supplied .woff2 file with CSS
@font-face and family name "Alan Font". Keep OFL.txt with any distributed
font files. Set language to ckb and text direction to rtl for Sorani.

Provenance

PROVENANCE.json records the base font, its hash, upstream notices,
target characters, and the license references consulted for this release.

Original project: https://github.com/BornaIz/Lalezar
Official license: https://openfontlicense.org/open-font-license-official-text/
Official FAQ: https://openfontlicense.org/ofl-faq/

Version 1.000

Included files
fonts/AlanFont-Regular.ttf — desktop and video use
fonts/AlanFont-Regular.woff2 — web use
Alan_Font_Preview.png — visual sample

Rebuild and verify
Install the packages in requirements.txt, then run scripts/build_font.py
and scripts/verify_font.py. The original unchanged font is in sources/.
The independent report checks coverage, contextual joining, regression
samples, source credit, names and embedding permissions.
